import os
import mysql.connector
from mysql.connector import Error
from dotenv import load_dotenv

load_dotenv()


def get_connection():
    """Connect to MySQL using settings from the .env file."""
    return mysql.connector.connect(
        host=os.getenv("DB_HOST", "localhost"),
        port=int(os.getenv("DB_PORT", "3306")),
        user=os.getenv("DB_USER", "root"),
        password=os.getenv("DB_PASSWORD", ""),
        database=os.getenv("DB_NAME", "student_db"),
    )


def add_student(conn):
    print("\n--- Add Student ---")
    register_no = input("Register number: ").strip()
    name = input("Student name: ").strip()
    department = input("Department: ").strip()
    year_text = input("Year (1-5): ").strip()
    contact = input("Contact number (optional): ").strip()

    if not register_no or not name or not department or not year_text:
        print("Register number, name, department, and year are required.")
        return
    try:
        year = int(year_text)
        if year < 1 or year > 5:
            print("Year must be between 1 and 5.")
            return
        with conn.cursor() as cursor:
            cursor.execute(
                """INSERT INTO students
                   (register_no, name, department, year, contact)
                   VALUES (%s, %s, %s, %s, %s)""",
                (register_no, name, department, year, contact or None),
            )
        conn.commit()
        print("Student record added successfully.")
    except ValueError:
        print("Please enter a valid number for year.")
    except Error as exc:
        conn.rollback()
        if getattr(exc, "errno", None) == 1062:
            print("A student with that register number already exists.")
        else:
            print(f"Could not add student: {exc}")


def view_students(conn):
    print("\n--- Student Records ---")
    try:
        with conn.cursor(dictionary=True) as cursor:
            cursor.execute(
                """SELECT register_no, name, department, year, contact
                   FROM students ORDER BY register_no"""
            )
            rows = cursor.fetchall()
        if not rows:
            print("No student records found.")
            return
        print("-" * 88)
        print(f"{'Register No.':<16}{'Name':<24}{'Department':<20}{'Year':<8}{'Contact'}")
        print("-" * 88)
        for row in rows:
            print(
                f"{row['register_no']:<16}{row['name'][:22]:<24}"
                f"{row['department'][:18]:<20}{row['year']:<8}"
                f"{row['contact'] or '-'}"
            )
        print("-" * 88)
    except Error as exc:
        print(f"Could not retrieve records: {exc}")


def search_student(conn):
    register_no = input("Enter register number to search: ").strip()
    try:
        with conn.cursor(dictionary=True) as cursor:
            cursor.execute(
                "SELECT register_no, name, department, year, contact "
                "FROM students WHERE register_no = %s",
                (register_no,),
            )
            row = cursor.fetchone()
        if row:
            print("\nStudent found:")
            for key, value in row.items():
                print(f"{key.replace('_', ' ').title()}: {value or '-'}")
        else:
            print("No student found with that register number.")
    except Error as exc:
        print(f"Search failed: {exc}")


def update_student(conn):
    register_no = input("Enter register number to update: ").strip()
    try:
        with conn.cursor(dictionary=True) as cursor:
            cursor.execute(
                "SELECT register_no, name, department, year, contact "
                "FROM students WHERE register_no = %s",
                (register_no,),
            )
            current = cursor.fetchone()
        if not current:
            print("Student record not found.")
            return

        print("Press Enter to keep the current value.")
        name = input(f"Name [{current['name']}]: ").strip() or current["name"]
        department = (
            input(f"Department [{current['department']}]: ").strip()
            or current["department"]
        )
        year_text = input(f"Year [{current['year']}]: ").strip()
        contact_text = input(f"Contact [{current['contact'] or '-'}]: ").strip()

        year = current["year"] if not year_text else int(year_text)
        if year < 1 or year > 5:
            print("Year must be between 1 and 5.")
            return
        contact = current["contact"] if not contact_text else contact_text

        with conn.cursor() as cursor:
            cursor.execute(
                """UPDATE students
                   SET name = %s, department = %s, year = %s, contact = %s
                   WHERE register_no = %s""",
                (name, department, year, contact or None, register_no),
            )
        conn.commit()
        print("Student record updated successfully.")
    except ValueError:
        print("Please enter a valid number for year.")
    except Error as exc:
        conn.rollback()
        print(f"Update failed: {exc}")


def delete_student(conn):
    register_no = input("Enter register number to delete: ").strip()
    confirm = input(f"Delete record {register_no}? (y/N): ").strip().lower()
    if confirm != "y":
        print("Deletion cancelled.")
        return
    try:
        with conn.cursor() as cursor:
            cursor.execute(
                "DELETE FROM students WHERE register_no = %s",
                (register_no,),
            )
            deleted = cursor.rowcount
        conn.commit()
        if deleted:
            print("Student record deleted successfully.")
        else:
            print("No student found with that register number.")
    except Error as exc:
        conn.rollback()
        print(f"Delete failed: {exc}")


def print_menu():
    print("\n========== Student Record Management System ==========")
    print("1. Add student")
    print("2. View all students")
    print("3. Search student")
    print("4. Update student")
    print("5. Delete student")
    print("0. Exit")


def main():
    try:
        conn = get_connection()
        print("Connected to MySQL successfully.")
    except (Error, ValueError) as exc:
        print("Could not connect to MySQL.")
        print(f"Details: {exc}")
        print("Check that MySQL is running and your .env settings are correct.")
        return

    actions = {
        "1": add_student,
        "2": view_students,
        "3": search_student,
        "4": update_student,
        "5": delete_student,
    }
    try:
        while True:
            print_menu()
            choice = input("Choose an option: ").strip()
            if choice == "0":
                print("Thank you for using the Student Record Management System.")
                break
            action = actions.get(choice)
            if action:
                action(conn)
            else:
                print("Invalid choice. Please select an option from the menu.")
    finally:
        conn.close()


if __name__ == "__main__":
    main()
