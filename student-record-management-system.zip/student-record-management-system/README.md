# Student Record Management System

A menu-based Python and MySQL project for managing student information. This project was developed as an institutional training project using Python, MySQL, and SQL.

## Features

- Add student records
- View all student records
- Search by register number
- Update existing records
- Delete records with confirmation
- Basic input validation and database error handling

## Technologies

- Python 3.9+
- MySQL
- `mysql-connector-python`
- `python-dotenv`
- SQL CRUD operations: `INSERT`, `SELECT`, `UPDATE`, and `DELETE`

## Student fields

- Register number (unique ID)
- Name
- Department
- Year
- Contact number (optional)

## Setup

### 1. Install Python and MySQL

Make sure Python and a MySQL server are installed and the MySQL service is running.

### 2. Create the database and table

Open MySQL Workbench or a MySQL terminal and run the contents of `database.sql`.

### 3. Install Python packages

From this project folder, run:

```bash
python -m pip install -r requirements.txt
```

### 4. Configure database connection

Copy `.env.example` to a new file named `.env` and edit the values to match your local MySQL settings.

Example:

```env
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=your_mysql_password
DB_NAME=student_db
```

Do not upload your real `.env` file or database password to GitHub. The `.gitignore` file excludes `.env`.

### 5. Run the application

```bash
python main.py
```

Choose an option from the menu and follow the prompts.

## Example menu

```text
========== Student Record Management System ==========
1. Add student
2. View all students
3. Search student
4. Update student
5. Delete student
0. Exit
```

## Project structure

```text
student-record-management-system/
├── main.py
├── database.sql
├── requirements.txt
├── .env.example
├── .gitignore
└── README.md
```

## Learning outcomes

This project demonstrates Python functions, menu-based programming, MySQL connectivity, SQL queries, CRUD operations, input validation, exception handling, and debugging.

## Academic note

This repository contains a starter implementation based on the project description in the institutional training report. Test it with your own MySQL setup and understand each function before presenting or demonstrating it in a viva.
